from app import app
from flask import flash, request, redirect, render_template,session,abort


import pymysql
db_name = "student_mgmt"
table = "admin_reg"
table2 = "student_reg"
table3 ="courses"
table4= "assignments"
table5 ="student_courses"
table6 = "student_assign"
table7 = "student_complaints"


@app.route('/')
def Main():
    return render_template('index.html')

@app.route('/admin_login')
def admin_login():
    return render_template('adm_login.html')

@app.route('/admin_login1',methods=['POST'])
def admin_login1():
    db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    Email_addr = request.form.get("email")
    passwd= request.form.get("password")

    if request.method == 'POST':

        user_email = Email_addr.lower()

        user_password = passwd.lower()
        cursor = db.cursor()
        cursor.execute('SELECT * FROM ' + table + ' WHERE Email = "%s" AND Password = "%s"' %(user_email,user_password))
        db.commit()
        x = cursor.rowcount
        if x > 0:
            for row in cursor:
                email = str(row[2]).lower()
                password = str(row[3]).lower()
                if email == user_email and password == user_password:
                    return render_template('admin_profile.html',name=str(row[0]),email=str(email))
                else:
                    flash('Enter valid credentials')
                    return redirect('/admin_login')
        else:
            return redirect('/admin_login')

@app.route('/admin_reg')
def admin_reg():

    return render_template('admin_reg.html')
@app.route("/admin_reg1",methods=['POST'])
def admin_reg1():
    db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    First_name = request.form.get("firstname")
    last_name = request.form.get("lastname")

    Email = request.form.get("email")
    Password = request.form.get("password")

    cursor = db.cursor()
    cursor.execute('INSERT INTO ' + table + ' VALUES (%s, %s, %s, %s)',
                   (First_name, last_name,
                    Email, Password))
    db.commit()
    return render_template('adm_login.html')

@app.route('/stu_login')
def stu_login():
    return render_template('login.html')

@app.route("/stu_login1",methods=['POST'])
def stu_login1():
    global email_address_q
    db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    Email_addr = request.form.get("email")
    passwd = request.form.get("password")

    if request.method == 'POST':

        user_email = Email_addr.lower()

        user_password = passwd.lower()
        cursor = db.cursor()
        cursor.execute(
            'SELECT * FROM ' + table2 + ' WHERE Email_address = "%s" AND Password = "%s"' % (user_email, user_password))
        db.commit()
        x = cursor.rowcount
        if x > 0:
            for row in cursor:
                email = str(row[5]).lower()
                email_address_q= email
                password = str(row[6]).lower()
                if email == user_email and password == user_password:

                    cursor.execute(
                        'SELECT * FROM ' + table3)
                    db.commit()
                    c = cursor

                    sql = db.cursor()

                    sql.execute(
                        'SELECT * FROM ' + table4)
                    db.commit()
                    assn = sql

                    return render_template('profile.html', name=str(row[0]),courses=c,number =row[4],email=row[5],formno=row[2],assignments=assn)
                else:
                    flash('Enter valid credentials')
                    return redirect('/stu_login')
        else:
            return redirect('/stu_login')




@app.route('/stu_reg')
def stu_reg():

    return render_template('stu_reg.html')

@app.route("/stu_reg1",methods=['POST'])
def stu_reg1():
    db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    name = request.form.get("username")
    course = request.form.get("course")
    semester = request.form.get("semester")
    Form_no = request.form.get("Form_no")
    Contact = request.form.get("Contact")
    Email = request.form.get("email")
    Password = request.form.get("password")
    Address = request.form.get("Address")
    cursor = db.cursor()
    cursor.execute('INSERT INTO ' + table2 + ' VALUES (%s, %s, %s, %s,%s, %s, %s, %s)', (name,course,semester,str(Form_no),str(Contact),
                                                                                         Email,Password,Address))
    db.commit()
    return render_template('login.html')






@app.route('/courses')
def courses():
    return render_template('courses.html')

@app.route('/courses1',methods=['POST'])
def courses1():
    db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    course_id = request.form.get("course_id")
    course_name = request.form.get("course_name")
    Description = request.form.get("Description")
    cursor = db.cursor()
    cursor.execute('INSERT INTO ' + table3 + ' VALUES (%s, %s, %s)',
                   (course_id, course_name, Description))
    db.commit()
    return render_template('courses.html')



@app.route('/assignments')
def assignments():
    return render_template('assignments.html')

@app.route('/assignments1',methods=['POST'])
def assignments1():
    db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    if request.method == 'POST':
        course_id = request.form.get("Assignment_id")
        course_name = request.form.get("Assignment_name")
        Description = request.form.get("Description")
        cursor = db.cursor()
        cursor.execute('INSERT INTO ' + table4 + ' VALUES (%s, %s, %s)',
                       (course_id, course_name, Description))
        db.commit()
    return render_template('assignments.html')

@app.route('/course_save',methods=['POST'])
def course_save():
    db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    if request.method == 'POST':
        global details, form, Name, c_name, email
        course_id_new = request.form.to_dict()
        for i in course_id_new:
            details = str(i)

        cursor = db.cursor()

        cursor.execute('SELECT * FROM ' + table2 + ' WHERE Email_address = "%s"' % (email_address_q))
        db.commit()
        x = cursor.rowcount
        if x > 0:
            for row in cursor:
                email = str(row[5]).lower()
                Name=str(row[0]).lower()
                form=str(row[3]).lower()

        course_n = db.cursor()
        course_n.execute('SELECT * FROM ' + table3 + ' WHERE Course_ID = "%s"' % (details))
        db.commit()
        x = course_n.rowcount
        if x > 0:
            for row in course_n:
                c_name = str(row[1]).lower()

        std_cr = db.cursor()

        std_cr.execute('INSERT INTO ' + table5 + ' VALUES (%s, %s, %s,%s, %s, %s)',(form, Name, details,c_name,"completed",email))

        db.commit()
        print('INSERT INTO ' + table4 + ' VALUES (%s, %s, %s,%s, %s, %s)',
              (form, Name, details, c_name, "completed", email))
        return "course added"


@app.route('/assign_course_save',methods=['POST'])
def assign_course_save():
    db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    if request.method == 'POST':
        global details, form, Name, c_name, email, assign_name
        assign_id_new = request.form.to_dict()
        for i in assign_id_new:
            details = str(i)

        cursor = db.cursor()

        cursor.execute('SELECT * FROM ' + table2 + ' WHERE Email_address = "%s"' % (email_address_q))
        db.commit()
        x = cursor.rowcount
        if x > 0:
            for row in cursor:
                email = str(row[5]).lower()
                Name = str(row[0]).lower()
                form = str(row[3]).lower()

        course_n = db.cursor()
        course_n.execute('SELECT * FROM ' + table4 + ' WHERE id = "%s"' % (details))
        db.commit()
        x = course_n.rowcount
        if x > 0:
            for row in course_n:
                assign_name = str(row[1]).lower()

        std_cr = db.cursor()

        std_cr.execute('INSERT INTO ' + table6  + ' VALUES (%s, %s,%s, %s, %s,%s)',
                       (form, Name, email , details, assign_name,"completed" ))

        db.commit()

        return "Assignment added"




@app.route('/completed_course')
def completed_course():
    db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    comp_course = db.cursor()
    comp_course.execute('SELECT * FROM ' + table5 + ' WHERE Email_address = "%s"' % (email_address_q))
    db.commit()
    cour = comp_course
    return render_template("completed_course.html",courses=cour)


@app.route('/completed_assign')
def completed_assign():
    db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    comp_course = db.cursor()
    comp_course.execute('SELECT * FROM ' + table6 + ' WHERE Email = "%s"' % (email_address_q))
    db.commit()
    cour = comp_course
    return render_template("completed_assign.html",assigns=cour)

@app.route('/student_complaints')
def student_complaints():
    return render_template("complaints.html")

@app.route('/student_complaints1',methods=['POST'])
def student_complaints1():
    if request.method =="POST":
        db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
        name = email_address_q
        message = request.form.get("message_area")
        complaint = db.cursor()
        complaint.execute('INSERT INTO ' + table7  + ' VALUES (%s, %s)',
                           (name,message))
        db.commit()

    return "complaint filed"

@app.route('/view_complaints')
def view_complaints():
    db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    view_com = db.cursor()
    view_com.execute('SELECT * FROM ' + table7)
    db.commit()
    complaints = view_com
    return render_template("view_complaints.html",complaints=complaints)