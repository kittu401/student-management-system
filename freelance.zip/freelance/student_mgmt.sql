-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2019 at 02:09 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_mgmt`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_reg`
--

CREATE TABLE `admin_reg` (
  `First Name` varchar(20) NOT NULL,
  `Last Name` varchar(20) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_reg`
--

INSERT INTO `admin_reg` (`First Name`, `Last Name`, `Email`, `Password`) VALUES
('kishore', 'kittu', 'kishorekittu401@gmail.com', 'pass@123'),
('kishore', 'kittu', 'kishorekittu401@gmail.com', 'asdfg'),
('kishore', 'kittu', 'demo@demo.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

CREATE TABLE `assignments` (
  `id` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignments`
--

INSERT INTO `assignments` (`id`, `Name`, `description`) VALUES
('as1', 'demo', 'testdemo'),
('as1', 'demo', 'demo assignment');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `Course_ID` varchar(20) NOT NULL,
  `Course_name` varchar(50) NOT NULL,
  `Description` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`Course_ID`, `Course_name`, `Description`) VALUES
('0', 'python3', 'Programming language'),
('py1', 'python3.8', 'new one'),
('py2', 'java', 'Programming language OOPS');

-- --------------------------------------------------------

--
-- Table structure for table `student_assign`
--

CREATE TABLE `student_assign` (
  `From No` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Assigmemt Id` varchar(50) NOT NULL,
  `Assigmemt Name` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_assign`
--

INSERT INTO `student_assign` (`From No`, `Name`, `Email`, `Assigmemt Id`, `Assigmemt Name`, `status`) VALUES
('1406', 'kishore', 'venkat.kishore610@gmail.com', 'as1', 'demo', 'completed'),
('1406', 'kishore', 'venkat.kishore610@gmail.com', 'as1', 'demo', 'completed'),
('1406', 'kishore', 'venkat.kishore610@gmail.com', 'as1', 'demo', 'completed'),
('1406', 'kishore', 'venkat.kishore610@gmail.com', 'as1', 'demo', 'completed');

-- --------------------------------------------------------

--
-- Table structure for table `student_complaints`
--

CREATE TABLE `student_complaints` (
  `Email_address` varchar(50) NOT NULL,
  `text` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_complaints`
--

INSERT INTO `student_complaints` (`Email_address`, `text`) VALUES
('venkat.kishore610@gmail.com', 'not good\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `student_courses`
--

CREATE TABLE `student_courses` (
  `Form No` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Course_id` varchar(50) NOT NULL,
  `course_name` varchar(50) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `Email_address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_courses`
--

INSERT INTO `student_courses` (`Form No`, `Name`, `Course_id`, `course_name`, `Status`, `Email_address`) VALUES
('1', 'kishore', '0', 'python3', 'completed', 'venkat.kishore610@gmail.com'),
('1406', 'kishore', '0', 'python3', 'completed', 'venkat.kishore610@gmail.com'),
('1406', 'kishore', '0', 'python3', 'completed', 'venkat.kishore610@gmail.com'),
('1406', 'kishore', '0', 'python3', 'completed', 'venkat.kishore610@gmail.com'),
('1406', 'kishore', '0', 'python3', 'completed', 'venkat.kishore610@gmail.com'),
('1406', 'kishore', 'py1', 'python3.8', 'completed', 'venkat.kishore610@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `student_reg`
--

CREATE TABLE `student_reg` (
  `Name` varchar(50) NOT NULL,
  `Course` varchar(50) NOT NULL,
  `Semester` varchar(50) NOT NULL,
  `FormNo` int(50) NOT NULL,
  `Contact Number` int(15) NOT NULL,
  `Email_address` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Address` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_reg`
--

INSERT INTO `student_reg` (`Name`, `Course`, `Semester`, `FormNo`, `Contact Number`, `Email_address`, `Password`, `Address`) VALUES
('kishore', 'ece', '1', 1406, 2147483647, 'venkat.kishore610@gmail.com', 'Kishore@1611', 'Pennada, agraharam.');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
