from app import app
from flask import flash, request, redirect, render_template, session, abort, make_response, url_for
from werkzeug.security import generate_password_hash,check_password_hash
from student_management.app.db import mysql
from student_management.app import app, COOKIE_TIME_OUT

import pymysql
db_name = "student_mgmt"
table = "admin_reg"
table2 = "student_reg"
table3 ="courses"
table4= "assignments"
table5 ="student_courses"
table6 = "student_assign"
table7 = "student_complaints"


@app.route('/')
def Main():
    return render_template('index.html')

@app.route('/admin_login')
def admin_login():
    return render_template('adm_login.html')

@app.route('/admin_reg')
def admin_reg():
    return render_template('admin_reg.html')

@app.route("/admin_reg1",methods=['POST'])
def admin_reg1():
    db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    First_name = request.form.get("firstname")
    last_name = request.form.get("lastname")

    Email = request.form.get("email")
    Password = request.form.get("password")
    New_password = generate_password_hash(password=Password)
    cursor = db.cursor()
    cursor.execute('INSERT INTO ' + table + ' VALUES (%s,%s, %s, %s, %s)',
                   (" ",First_name, last_name,
                    Email, New_password))
    db.commit()
    return render_template('adm_login.html')


@app.route('/admin_login1',methods=['POST',"GET"])
def admin_login1():
    conn = None
    cursor = None

    _email = request.form['inputEmail']
    _password = request.form['inputPassword']
    if request.method == 'POST':
        if _email and _password:
            # check user exists
            conn = mysql.connect()
            cursor = conn.cursor()
            sql = "SELECT * FROM admin_reg WHERE Email=%s"
            sql_where = (_email,)
            cursor.execute(sql, sql_where)
            row = cursor.fetchone()
            if row:
                if check_password_hash(row[4], _password):
                    session['email'] = row[3]
                    session["name"]=str(row[1]+" "+row[2])
                    cursor.close()
                    conn.close()
                    return render_template('admin_profile.html', name=str(row[1]+" "+row[2]), email=str(_email))
                else:
                    flash('Enter valid credentials')
                    return redirect('/admin_login')
            else:
                flash('Enter valid credentials')
                return redirect('/admin_login')
        else:
            flash('Enter valid credentials')
            return redirect('/admin_login')
    elif 'email' in session:
        conn = mysql.connect()
        cursor = conn.cursor()
        sql = "SELECT * FROM admin_reg WHERE Email=%s"
        _email = session['email']
        sql_where = (_email,)
        cursor.execute(sql, sql_where)
        row = cursor.fetchone()
        if row:
            if check_password_hash(row[4], _password):
                session['email'] = row[3]
                session["name"] = str(row[1] + " " + row[2])
                cursor.close()
                conn.close()
                return render_template('admin_profile.html', name=str(row[1] + " " + row[2]), email=str(_email))
        else:
            flash('Enter valid credentials')
            return redirect('/admin_login')


@app.route('/adminhome',methods=['POST',"GET"])
def adminhome():
    if 'email' in session:
        conn = mysql.connect()
        cursor = conn.cursor()
        sql = "SELECT * FROM admin_reg WHERE Email=%s"
        _email = session['email']
        sql_where = (_email,)
        cursor.execute(sql, sql_where)
        row = cursor.fetchone()
        if row:
            return render_template('admin_profile.html', name=str(row[1] + " " + row[2]), email=str(_email))
        else:
            flash('Enter valid credentials')
            return redirect('/admin_login')

@app.route('/stu_login')
def stu_login():
    return render_template('login.html')


@app.route('/stu_login1', methods=['POST'])
def stu_login1():
    conn = None
    cursor = None

    _email = request.form['inputEmail']
    _password = request.form['inputPassword']
    global username
    username = _email
    if _email and _password:
            # check user exists
            conn = mysql.connect()
            cursor = conn.cursor()
            sql = "SELECT * FROM student_reg WHERE Email_address=%s"
            sql_where = (_email,)
            cursor.execute(sql, sql_where)
            row = cursor.fetchone()
            if row:
                    if check_password_hash(row[7], _password):
                        session['email'] = row[6]
                        cursor.close()
                        conn.close()
                        conn = mysql.connect()  # intial connection

                        cursor = conn.cursor()
                        sql_course = "SELECT * FROM courses;"
                        cursor.execute(sql_course)
                        c = cursor.fetchall()

                        cursor.close()
                        conn.close()

                        conn = mysql.connect()  # intial connection
                        cursor = conn.cursor()
                        sql_assignments = "SELECT * FROM assignments"
                        cursor.execute(sql_assignments)
                        assn = cursor.fetchall()

                        cursor.close()
                        conn.close()

                        conn = mysql.connect()  # intial connection
                        cursor = conn.cursor()
                        sql_comp_course = "SELECT * FROM student_courses WHERE Email_address=%s"
                        sql_where = (username)
                        cursor.execute(sql_comp_course, sql_where)
                        cour = cursor.fetchall()

                        cursor.close()
                        conn.close()

                        conn = mysql.connect()  # intial connection
                        cursor = conn.cursor()
                        sql_comp_assign = "SELECT * FROM student_assign WHERE Email =%s"
                        sql_where = (username)
                        cursor.execute(sql_comp_assign, sql_where)

                        comp_assn = cursor.fetchall()
                        cursor.close()
                        conn.close()

                        return render_template('profile.html', name=str(row[1]), courses=c, number=row[4],
                                               email=row[5], formno=row[2], assignments=assn,
                                               comp_courses=cour, comp_assigns=comp_assn)
                    else:
                        flash('Enter valid credentials')
                        return redirect('/stu_login')


            else:
                flash('Invalid email/password!')
                return redirect('/stu_login')
    else:
        flash('Invalid email/password!')
        return redirect('/stu_login')


@app.route('/profiles')
def profiles():
    conn = None
    cursor = None

    _email = session['email']
    global username
    username = _email
    print(username)
    if _email:
            # check user exists
            conn = mysql.connect()
            cursor = conn.cursor()
            sql = "SELECT * FROM student_reg WHERE Email_address=%s"
            sql_where = (_email,)
            cursor.execute(sql, sql_where)
            row = cursor.fetchone()
            if row:
                    session['email'] = row[6]
                    cursor.close()
                    conn.close()
                    conn = mysql.connect()  # intial connection

                    cursor = conn.cursor()
                    sql_course = "SELECT * FROM courses;"
                    cursor.execute(sql_course)
                    c = cursor.fetchall()

                    cursor.close()
                    conn.close()

                    conn = mysql.connect()  # intial connection
                    cursor = conn.cursor()
                    sql_assignments = "SELECT * FROM assignments"
                    cursor.execute(sql_assignments)
                    assn = cursor.fetchall()

                    cursor.close()
                    conn.close()

                    conn = mysql.connect()  # intial connection
                    cursor = conn.cursor()
                    sql_comp_course = "SELECT * FROM student_courses WHERE Email_address=%s"
                    sql_where = (username)
                    cursor.execute(sql_comp_course, sql_where)
                    cour = cursor.fetchall()

                    cursor.close()
                    conn.close()

                    conn = mysql.connect()  # intial connection
                    cursor = conn.cursor()
                    sql_comp_assign = "SELECT * FROM student_assign WHERE Email =%s"
                    sql_where = (username)
                    cursor.execute(sql_comp_assign, sql_where)

                    comp_assn = cursor.fetchall()
                    cursor.close()
                    conn.close()

                    return render_template('profile.html', name=str(row[1]), courses=c, number=row[4],
                                           email=row[5], formno=row[2], assignments=assn,
                                           comp_courses=cour, comp_assigns=comp_assn)


            else:
                flash('Invalid email/password!')
                return redirect('/stu_login')
    else:
        flash('Invalid email/password!')
        return redirect('/stu_login')

@app.route('/studentcourses')
def studentcourses():
    conn = None
    cursor = None

    _email = session['email']
    global username
    username = _email
    print(username)
    if _email:
            # check user exists
            conn = mysql.connect()
            cursor = conn.cursor()
            sql = "SELECT * FROM student_reg WHERE Email_address=%s"
            sql_where = (_email,)
            cursor.execute(sql, sql_where)
            row = cursor.fetchone()
            if row:
                    session['email'] = row[6]
                    cursor.close()
                    conn.close()
                    conn = mysql.connect()  # intial connection

                    cursor = conn.cursor()
                    sql_course = "SELECT * FROM courses;"
                    cursor.execute(sql_course)
                    c = cursor.fetchall()

                    cursor.close()
                    conn.close()


                    conn = mysql.connect()  # intial connection
                    cursor = conn.cursor()
                    sql_comp_course = "SELECT * FROM student_courses WHERE Email_address=%s"
                    sql_where = (username)
                    cursor.execute(sql_comp_course, sql_where)
                    cour = cursor.fetchall()

                    cursor.close()
                    conn.close()



                    return render_template('student_courses.html', name=str(row[1]), courses=c, number=row[4],
                                           email=row[5], formno=row[2],
                                           comp_courses=cour)


            else:
                flash('Invalid email/password!')
                return redirect('/stu_login')
    else:
        flash('Invalid email/password!')
        return redirect('/stu_login')


@app.route('/studentassignments')
def studentassignments():
    conn = None
    cursor = None

    _email = session['email']
    global username
    username = _email
    print(username)
    if _email:
            # check user exists
            conn = mysql.connect()
            cursor = conn.cursor()
            sql = "SELECT * FROM student_reg WHERE Email_address=%s"
            sql_where = (_email,)
            cursor.execute(sql, sql_where)
            row = cursor.fetchone()
            if row:
                    session['email'] = row[6]
                    cursor.close()
                    conn.close()

                    conn = mysql.connect()  # intial connection
                    cursor = conn.cursor()
                    sql_assignments = "SELECT * FROM assignments"
                    cursor.execute(sql_assignments)
                    assn = cursor.fetchall()

                    cursor.close()
                    conn.close()

                    conn = mysql.connect()  # intial connection
                    cursor = conn.cursor()
                    sql_comp_assign = "SELECT * FROM student_assign WHERE Email =%s"
                    sql_where = (username)
                    cursor.execute(sql_comp_assign, sql_where)

                    comp_assn = cursor.fetchall()
                    cursor.close()
                    conn.close()

                    return render_template('student_assignments.html', name=str(row[1]), number=row[4],
                                           email=row[5], formno=row[2], assignments=assn,
                                           comp_assigns=comp_assn)


            else:
                flash('Invalid email/password!')
                return redirect('/stu_login')
    else:
        flash('Invalid email/password!')
        return redirect('/stu_login')

@app.route('/stu_reg')
def stu_reg():

    return render_template('stu_reg.html')

@app.route("/stu_reg1",methods=['POST'])
def stu_reg1():
    db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    name = request.form.get("username")
    course = request.form.get("course")
    semester = request.form.get("semester")
    Form_no = request.form.get("Form_no")
    Contact = request.form.get("Contact")
    Email = request.form.get("email")
    Password = request.form.get("password")
    Address = request.form.get("Address")
    new_password = generate_password_hash(password=Password)
    cursor = db.cursor()
    cursor.execute('INSERT INTO ' + table2 + ' VALUES (%s,%s, %s, %s, %s,%s, %s, %s, %s)', (" ",name,course,semester,str(Form_no),str(Contact),
                                                                                         Email,new_password,Address))
    db.commit()
    return render_template('login.html')




@app.route('/courses')
def courses():
    return render_template('courses.html')

@app.route('/courseslist')
def coursesList():
    conn = mysql.connect()
    cursor = conn.cursor()
    std_c_name = "SELECT * FROM courses"
    cursor.execute(std_c_name)
    assn = cursor.fetchall()
    return render_template('courses_list.html', courses = assn, name= session["name"])

@app.route('/assignmentslist')
def assignmentsList():
    conn = mysql.connect()
    cursor = conn.cursor()
    std_c_name = "SELECT * FROM assignments"
    cursor.execute(std_c_name)
    assn = cursor.fetchall()
    return render_template('assignments_list.html', assignments = assn, name=session["name"])

@app.route('/createcourse',methods=['POST'])
def createcourse():
    db = mysql.connect()
    course_id = request.form.get("course_id")
    course_name = request.form.get("course_name")
    Description = request.form.get("Description")
    cursor = db.cursor()
    cursor.execute('INSERT INTO ' + table3 + ' (Course_ID, Course_name, Description) VALUES (%s, %s, %s)', (course_id, course_name, Description))
    db.commit()
    return redirect('/courseslist')

@app.route('/createassignment',methods=['POST'])
def createassignment():
    db = mysql.connect()
    assignmentID = request.form.get("Assignment_id")
    assignmentName = request.form.get("Assignment_name")
    description = request.form.get("Description")
    cursor = db.cursor()
    cursor.execute('INSERT INTO assignments (id, Name, Description) VALUES (%s, %s, %s)', (assignmentID, assignmentName, description))
    db.commit()
    return redirect('/assignmentslist')

@app.route('/coursesedit',methods=['POST'])
def courseEdit():
    db = mysql.connect()
    course_id = request.form.get("course_id")
    course_name = request.form.get("course_name")
    Description = request.form.get("Description")
    cursor = db.cursor()
    cursor.execute('UPDATE courses set Course_name=%s,Description=%s where Course_ID= %s',
                   (course_name, Description, course_id))
    db.commit()
    return redirect('/courseslist')


@app.route('/course_add',methods=['POST'])
def course_add():
    global details, form, Name, c_name, email
    #db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    if request.method == 'POST':
        print(request)
        course_id_new = request.form.to_dict()
        print(course_id_new.values())
        for i in course_id_new:
            details = str(i)
            if(course_id_new.get(details) == 'Edit'):
                courseID = ''
                courseName=''
                Description=''
                conn = mysql.connect()
                cursor = conn.cursor()
                std_c_name = "SELECT * FROM courses WHERE Course_ID = %s"
                sql_where = (details)
                cursor.execute(std_c_name, sql_where)
                assn = cursor.fetchall()
                x = cursor.rowcount
                if x == 1:
                    for row in assn:
                        courseID = str(row[1])
                        courseName = str(row[2])
                        Description = str(row[3])
                return render_template('course_edit.html', course_id=courseID, course_name=courseName, Description=Description)
            elif(course_id_new.get(details) =='Delete'):
                conn = mysql.connect()
                cursor = conn.cursor()
                std_c_name = "DELETE FROM courses WHERE Course_ID = %s"
                sql_where = (details)
                cursor.execute(std_c_name, sql_where)
                conn.commit()
                return redirect('/courseslist')
            print(course_id_new.get(details))

    return redirect('/courseslist')

@app.route('/assignment_ops',methods=['POST'])
def assignment_ops():
    global details, form, Name, c_name, email
    #db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    if request.method == 'POST':
        print(request)
        course_id_new = request.form.to_dict()
        print(course_id_new.values())
        for i in course_id_new:
            details = str(i)
            if(course_id_new.get(details) == 'Edit'):
                assignmentID = ''
                name=''
                Description=''
                conn = mysql.connect()
                cursor = conn.cursor()
                std_c_name = "SELECT * FROM assignments WHERE id = %s"
                sql_where = (details)
                cursor.execute(std_c_name, sql_where)
                assn = cursor.fetchall()
                x = cursor.rowcount
                if x == 1:
                    for row in assn:
                        assignmentID = str(row[1])
                        name = str(row[2])
                        Description = str(row[3])
                return render_template('assignment_edit.html', Assignment_id=assignmentID, Assignment_name=name, Description=Description)
            elif(course_id_new.get(details) =='Delete'):
                conn = mysql.connect()
                cursor = conn.cursor()
                std_c_name = "DELETE FROM assignments WHERE id = %s"
                sql_where = (details)
                cursor.execute(std_c_name, sql_where)
                conn.commit()
                return redirect('/assignmentslist')
            print(course_id_new.get(details))

    return redirect('/assignmentslist')


@app.route('/assignments')
def assignments():
    return render_template('assignments.html')

@app.route('/assignmentsedit',methods=['POST'])
def assignmentsedit():
    db = mysql.connect()
    if request.method == 'POST':
        assignmentID = request.form.get("Assignment_id")
        assignmentName = request.form.get("Assignment_name")
        description = request.form.get("Description")
        cursor = db.cursor()
        cursor.execute('UPDATE assignments SET Name =%s,Description = %s WHERE id = %s', (assignmentName, description, assignmentID))
        db.commit()
    return redirect('/assignmentslist')

@app.route('/course_save',methods=['POST'])
def course_save():
    global details, form, Name, c_name, email
    #db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    if request.method == 'POST':
        print(request.form)
        course_id_new = request.form.to_dict()
        for i in course_id_new:
            details = str(i)
            print(details)
        conn = mysql.connect()  # intial connection
        cursor = conn.cursor()
        std_d = "SELECT * FROM student_reg WHERE Email_address = %s"
        sql_where = (username)
        print(username)
        cursor.execute(std_d,sql_where)
        assn = cursor.fetchall()
        print(assn)
        x = cursor.rowcount
        print(x)
        if x > 0:
            for row in assn:
                email = str(row[6]).lower()
                Name = str(row[1]).lower()
                form = str(row[4]).lower()
        cursor.close()
        conn.close()

        conn = mysql.connect()
        cursor = conn.cursor()
        std_c_name = "SELECT * FROM courses WHERE Course_ID = %s"
        sql_where = (details)
        cursor.execute(std_c_name, sql_where)
        assn = cursor.fetchall()

        for row in assn:
            c_name = str(row[2]).lower()
            print(c_name)
        cursor.close()
        conn.close()

        conn = mysql.connect()  # intial connection
        cursor = conn.cursor()
        cursor.execute('INSERT INTO ' + table5 + ' (Form_No, Name, Course_id, course_name, Status, Email_address) VALUES (%s, %s, %s,%s, %s, %s)',(form, Name, details,c_name,"completed",email))
        conn.commit()
        cursor.close()
        conn.close()
        return redirect('/studentcourses')
        #return "course added"


@app.route('/assign_course_save',methods=['POST'])
def assign_course_save():
    #db = pymysql.connect(host='localhost', database=db_name, user='', passwd='')
    if request.method == 'POST':
        details=''
        form=''
        Name=''
        c_name=''
        email=''
        assign_name=''

        assign_id_new = request.form.to_dict()
        for i in assign_id_new:
            details = str(i)
            print(details)

        db = mysql.connect()
        cursor = db.cursor()
        print(username)
        std_d = "SELECT * FROM student_reg WHERE Email_address = %s"
        sql_where = (username)
        print(username)
        cursor.execute(std_d, sql_where)
        assn = cursor.fetchall()
        x = cursor.rowcount
        print(x)
        if x > 0:
            for row in assn:
                email = str(row[6]).lower()
                Name = str(row[1]).lower()
                form = str(row[4]).lower()

        course_n = db.cursor()
        std_d = "SELECT * FROM assignments WHERE id = %s"
        sql_where = (details)
        course_n.execute(std_d, sql_where)
        assn = cursor.fetchall()
        db.commit()
        x = course_n.rowcount
        if x > 0:
            for row in course_n:
                assign_name = str(row[2]).lower()

        std_cr = db.cursor()
        print(form)
        std_cr.execute('INSERT INTO ' + table6  + ' (Form_No,Name, Email, Assigmemt_Id, Assigmemt_Name, status) VALUES (%s, %s,%s, %s, %s,%s)',
                       (form, Name, email , details, assign_name,"completed" ))
        db.commit()

        return redirect('/studentassignments')




@app.route('/completed_course')
def completed_course():
    db = mysql.connect()
    comp_course = db.cursor()
    comp_course.execute('SELECT * FROM ' + table5 + ' WHERE Email_address = "%s"' % (username))
    db.commit()
    cour = comp_course
    return render_template("completed_course.html",courses=cour)


@app.route('/completed_assign')
def completed_assign():
    db = mysql.connect()
    comp_course = db.cursor()
    comp_course.execute('SELECT * FROM ' + table6 + ' WHERE Email = "%s"' % (username))
    db.commit()
    cour = comp_course
    return render_template("completed_assign.html",assigns=cour)

@app.route('/student_complaints')
def student_complaints():
    return render_template("raise_complaint.html")

@app.route('/student_complaints1',methods=['POST'])
def student_complaints1():
    if request.method =="POST":
        db = mysql.connect()
        name = username
        message = request.form.get("message_area")
        complaint = db.cursor()
        complaint.execute('INSERT INTO ' + table7  + ' (Email_address, text) VALUES (%s, %s)',
                           (name,message))
        db.commit()
    return redirect('/student_raised_complaints')

@app.route('/student_raised_complaints')
def student_raised_complaints():
    db = mysql.connect()
    complaints = db.cursor()
    complaints.execute('SELECT * FROM student_complaints WHERE Email_address = "%s"' % (username))
    db.commit()
    cour = complaints
    return render_template("student_complaints.html",complaints=cour)

@app.route('/view_complaints')
def view_complaints():
    db = mysql.connect()
    view_com = db.cursor()
    view_com.execute('SELECT * FROM ' + table7)
    db.commit()
    complaints = view_com
    return render_template("view_complaints.html",complaints=complaints)

@app.route('/admin_view_complaints')
def admin_view_complaints():
    db = mysql.connect()
    view_com = db.cursor()
    view_com.execute('SELECT * FROM ' + table7)
    db.commit()
    complaints = view_com
    return render_template("admin_view_complaints.html",complaints=complaints)

@app.route('/logout')
def logout():
    if 'email' in session:
        session.pop('email', None)
    return redirect('/')